/***********************************************************************
* COSC1076 - Advanced Programming Techniques
* Semester 2 2015 Assignment #1 
* Full Name        : Yehui Chen
* Student Number   : s3189978
* Course Code      : COSC1076
* Program Code     : BP232
* Start up code provided by Paul Miller
***********************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include "board.h"
#include "helpers.h"
#include "scoreboard.h"
#include "player.h"
#include "game.h"
#include "bool.h"
/**
 * @file con4.h simply puts together all the other header files for 
 * inclusion in @ref con4.c
 **/

